package service;

public interface IStudentService {
     void addStudent();

    void displayAllStudent();

    void removeStudent();
}
